#include <iostream>
using namespace std;

int main() {
     cout << "Hello MxOxW!\n" << endl;
     cout << " \n" << endl;
     cout << "Are you prepared for this semester?\n" << endl;
     cout << "Im prepared for this semester.\n" << endl;
     // im moderatly prepaired
     return 0;   
}

